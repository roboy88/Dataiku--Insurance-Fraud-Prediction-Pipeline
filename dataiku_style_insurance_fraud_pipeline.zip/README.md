# Dataiku-Style Insurance Fraud Prediction Pipeline

This repository contains a modular, production-ready machine learning pipeline inspired by Dataiku flows.

## Project Overview

- **Goal:** Predict fraudulent insurance claims
- **Workflow:**
    1. Ingest and clean data
    2. Engineer features
    3. Train Random Forest classifier
    4. Evaluate performance
    5. Deploy model for inference

## Folder Structure

- `data/`: Sample CSV files
- `scripts/`: Python scripts (ETL, feature engineering, modeling)
- `models/`: Serialized model artifacts
- `logs/`: Execution logs and outputs

## Usage

```bash
python scripts/train_model.py
```

To make a new prediction:

```python
from scripts.predict import predict_new_claim
predict_new_claim(0.7)
```
